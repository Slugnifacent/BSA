#include <string>
#include "FileObject.cpp"
#include "ShellCommands.cpp"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

class FileObjectManager
{
	private:
		vector<FileObject> files;
		vector< string > NameOccourances;
		void CheckFilenameOccourance();

	public:
		FileObjectManager();
		void AddFileObject(string Filename);
		void PrintList();
		void PerformShellCommand();

};

FileObjectManager::FileObjectManager()
{

}

void FileObjectManager::AddFileObject(const string Filename)
{
	// insert into List
	FileObject fileobject(Filename);
	files.push_back(fileobject);

	// Check Filename Occourance
	string filename = fileobject.getFilename();
	for(std::vector<string>::iterator it = NameOccourances.begin(); it != NameOccourances.end(); ++it) {
		string tempFilename = *it;
		if (tempFilename.compare(filename) == 0)
		{
			fileobject.IncrementInstance();
		} 
	}
	NameOccourances.push_back(filename);

}


void FileObjectManager::PrintList()
{
	for(std::vector<FileObject >::iterator it = files.begin(); it != files.end(); ++it) {
		FileObject fileobject = *it;
		string result = fileobject.ToString();
    	printf("%s",result.c_str());
	}
}

void FileObjectManager::PerformShellCommand()
{
	const int BUFFERCOUNT=256;
	char OriginalFilenameBuffer[BUFFERCOUNT];
	char NewFileNameBuffer[BUFFERCOUNT];

	string Directory = "To-SFX-Library-Remamed";
	ShellCommands::MakeDirectory(Directory);

	for(std::vector<FileObject >::iterator it = files.begin(); it != files.end(); it++) {	
		FileObject fileobject = *it;

		// Construct New File Name
		// FEATURE: Appened integer to name clashes
			// if Instance Greater than 1 Add rename Modifier
			//	int instance = fileobject.getInstance();
			//	if( instance > 0) sprintf(NewFileNameBuffer,"\"%s/$(basename \"%s\")_%d%s\" ", Directory.c_str(),fileobject.getFilename().c_str(),instance,fileobject.getExtension().c_str());
			//	else sprintf(NewFileNameBuffer,"\"%s/$(basename \"%s\")%s\" ", Directory.c_str(),fileobject.getFilename().c_str(),fileobject.getExtension().c_str());
	
		// FEATURE: Use Old filename		
		sprintf(NewFileNameBuffer,"\"%s/$(basename \"%s\")\" ", Directory.c_str(),fileobject.getOriginalFilename().c_str());

		// Wrap string in Parentheses to handle spaces
		sprintf(OriginalFilenameBuffer,"\"%s\"", fileobject.getOriginalFilename().c_str());

		ShellCommands::Copy(OriginalFilenameBuffer, NewFileNameBuffer);
		ShellCommands::InjectMetaDataDescription(NewFileNameBuffer,fileobject.getDescription());
	}
}