#include <stdlib.h>
#include <string>

#define COMMANDBUFFER_SIZE 512
 
class ShellCommands{
	private:
		char static CommandBuffer[COMMANDBUFFER_SIZE];
		void static ClearBuffer();

	public:
		void static Custom(string Command);
		void static Copy(string Filename, string Location);
		void static InjectMetaDataDescription(string Filename, string Description);
		void static MakeDirectory(string Command);
		
};

char ShellCommands::CommandBuffer[COMMANDBUFFER_SIZE];

void ShellCommands::Custom(string Command)
{
	ClearBuffer();
}

void ShellCommands::Copy(string Filename, string Location)
{
	ClearBuffer();
	sprintf(CommandBuffer,"cp %s %s", Filename.c_str(),Location.c_str());
	system(CommandBuffer);

}

void ShellCommands::MakeDirectory(string Directory)
{
	ClearBuffer();
	sprintf(CommandBuffer,"mkdir %s", Directory.c_str());
	system(CommandBuffer);
}


void ShellCommands::InjectMetaDataDescription(string Filename, string Description)
{
	ClearBuffer();
	string BMWEDIT="/Users/bijan/joshScripts/Project/GNU/CLI/bwfmetaedit --Description=";
	sprintf(CommandBuffer,"%s\"%s\" %s", BMWEDIT.c_str(),Description.c_str(),Filename.c_str());
	system(CommandBuffer);

}

void ShellCommands::ClearBuffer()
{
	CommandBuffer[0]=0;
}