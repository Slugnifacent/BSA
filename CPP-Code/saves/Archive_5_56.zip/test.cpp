#include <iostream>
#include <string>
#include <map>
#include <Vector>
#include <boost/filesystem.hpp>
#include <boost/tokenizer.hpp>
#include "FileObjectManager.cpp"

using std::cout;
using namespace boost::filesystem;
using namespace std;

int main(int argc , char * argv[]) {

 path p (argv[1]);
 FileObjectManager filemanager;
 string filetype=".wav";

  try
  {
    if (exists(p))
    {
      if (is_regular_file(p))
        cout << p << " size is " << file_size(p) << '\n';

      else if (is_directory(p))
      {
        cout << p << " is a directory containing:\n";

		  recursive_directory_iterator it(p);
      cout << "ExtractNameAndDesc 1\n";
		  while (it != recursive_directory_iterator())

		  	if(!is_directory(*it))
		  	{
          cout << "ExtractNameAndDesc 1\n";
          directory_entry& directory  = *it++;
		    	string filename = directory.path().string();
          if(directory.path().extension().string().compare(filetype) == 0)
          {
            filemanager.AddFileObject(filename);
          }

		    } else {

          if (it->path().filename().string().compare("To-SFX-Library-Remamed") == 0)
          {
              cout << it->path().filename().string() << " no_push\n";
              it.no_push();
          } 

          *it++;
        }
		}
      else
        cout << p << " exists, but is not a regular file or directory\n";
    }
    else
      cout << p << " does not exist\n";
  }

  catch (const filesystem_error& ex)
  {
    cout << ex.what() << '\n';
  }

  filemanager.PrintList();
  filemanager.PerformShellCommand();
  cout << "Success\n";
return 0;
}

